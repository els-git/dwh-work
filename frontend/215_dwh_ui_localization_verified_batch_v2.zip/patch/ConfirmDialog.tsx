import { Trans } from 'react-i18next'
import {
  useEffect,
} from 'react'

import './ConfirmDialog.css'


interface ConfirmDialogProps {
  open: boolean
  title: string
  message: string
  detail?: string
  confirmLabel?: string
  cancelLabel?: string
  busy?: boolean
  onConfirm: () => void
  onCancel: () => void
}


function ConfirmDialog({
  open,
  title,
  message,
  detail,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  busy = false,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  useEffect(() => {
    if (!open) {
      return
    }

    function handleKeyDown(
      event: KeyboardEvent,
    ) {
      if (
        event.key === 'Escape'
        && !busy
      ) {
        onCancel()
      }
    }

    window.addEventListener(
      'keydown',
      handleKeyDown,
    )

    return () => {
      window.removeEventListener(
        'keydown',
        handleKeyDown,
      )
    }
  }, [
    open,
    busy,
    onCancel,
  ])


  if (!open) {
    return null
  }


  return (
    <div
      className="confirm-dialog-backdrop"
      role="presentation"
      onMouseDown={
        event => {
          if (
            event.target === event.currentTarget
            && !busy
          ) {
            onCancel()
          }
        }
      }
    >
      <section
        className="confirm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
      >
        <div className="confirm-dialog-accent" />

        <div className="confirm-dialog-content">
          <div className="confirm-dialog-eyebrow">
            <Trans i18nKey="batch.tr0102" />
          </div>

          <h2 id="confirm-dialog-title">
            {title}
          </h2>

          <p className="confirm-dialog-message">
            {message}
          </p>

          {
            detail
              ? (
                <div className="confirm-dialog-detail">
                  {detail}
                </div>
              )
              : null
          }

          <div className="confirm-dialog-actions">
            <button
              type="button"
              className="confirm-dialog-cancel"
              disabled={busy}
              onClick={onCancel}
            >
              {cancelLabel}
            </button>

            <button
              type="button"
              className="confirm-dialog-confirm"
              disabled={busy}
              autoFocus
              onClick={onConfirm}
            >
              {
                busy
                  ?<Trans i18nKey="batch.tr0115" />
                  : confirmLabel
              }
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}


export default ConfirmDialog