import hashlib
import json
import re
import shutil
import subprocess
import sys
import uuid
import zipfile
from datetime import datetime
from pathlib import Path

root = Path(sys.argv[1])
package = Path(sys.argv[2])
frontend = root / 'frontend'
src = frontend / 'src'
backup_base = root / 'runtime' / 'temp' / 'backups'
eslint = frontend / 'node_modules' / 'eslint' / 'bin' / 'eslint.js'
EXPECTED_PACKAGE = sys.argv[3]
source_before = {}
originals = {}
patches = {}
backups = {}
manifest = None
started = False
phase = 'initial checks'

def require(ok, description):
    if not ok:
        raise RuntimeError(description)

def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()

def hash_file(path):
    return hash_bytes(path.read_bytes())

def snapshot():
    return {
        p.relative_to(src).as_posix(): hash_file(p)
        for p in src.rglob('*') if p.is_file()
    }

def run_checked(args):
    return subprocess.run(
        args, cwd=str(frontend), stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, encoding='utf-8',
        errors='replace', timeout=300, check=False,
    )

def build_and_lint(node, npm):
    print('=== PRODUCTION BUILD ===', flush=True)
    build = run_checked([npm, 'run', 'build'])
    print('BUILD EXIT CODE:', build.returncode, flush=True)
    if build.returncode:
        print(build.stdout[-5000:], flush=True)
    require(build.returncode == 0, 'TypeScript/Vite build failed')
    print('=== FULL ESLINT ===', flush=True)
    lint = run_checked([node, str(eslint), '.', '--format', 'json'])
    try:
        records = json.loads(lint.stdout)
    except ValueError:
        print(lint.stdout[-5000:], flush=True)
        raise RuntimeError('Full ESLint output invalid')
    require(isinstance(records, list) and len(records) > 0,
            'ESLint did not report checked source files')
    errors = sum(int(item.get('errorCount', 0)) for item in records)
    warnings = sum(int(item.get('warningCount', 0)) for item in records)
    print('ESLINT ERRORS:', errors, flush=True)
    print('ESLINT WARNINGS:', warnings, flush=True)
    require(lint.returncode == 0 and errors == 0 and warnings == 0,
            'ESLint not 0/0')

try:
    print('=== STEP 215: BULK UI LOCALIZATION ===', flush=True)
    require(src.is_dir(), 'Frontend src directory missing')
    require(package.is_file(), 'Approved patch ZIP missing')
    require(hash_file(package) == EXPECTED_PACKAGE,
            'Patch ZIP SHA256 is not the approved version')
    require(eslint.is_file(), 'Local ESLint installation missing')
    node = shutil.which('node.exe') or shutil.which('node')
    npm = shutil.which('npm.cmd') or shutil.which('npm')
    require(node and npm, 'Node.js or npm not available')
    require((frontend / 'package.json').is_file(), 'package.json missing')
    require((frontend / 'package-lock.json').is_file(), 'package-lock.json missing')

    phase = 'manifest and current baseline verification'
    with zipfile.ZipFile(package, 'r') as archive:
        manifest = json.loads(archive.read('manifest.json'))
        require(manifest.get('step') == '215', 'Unexpected patch step')
        require(manifest.get('changes_count') == 17 and
                manifest.get('jsx_replacements') == 671 and
                manifest.get('new_i18n_keys') == 362,
                'Unexpected patch scope')
        items = manifest.get('files')
        require(isinstance(items, list) and len(items) == 17,
                'Unexpected patched file inventory')
        require(len({x['path'] for x in items}) == 17,
                'Duplicate patched filename')
        source_before = snapshot()
        require(len(source_before) >= 17, 'Incomplete frontend source inventory')
        for item in items:
            rel = item['path']
            require(isinstance(rel, str) and
                    re.fullmatch(r'[A-Za-z0-9_-]+\.tsx?', rel) is not None,
                    'Unexpected source path in manifest')
            target = src / rel
            require(target.is_file() and not target.is_symlink(),
                    'Missing or symbolic source: ' + rel)
            current = target.read_bytes()
            replacement = archive.read('patch/' + rel)
            require(hash_bytes(current) == item['old_sha256'],
                    'Original source SHA256 differs: ' + rel)
            require(hash_bytes(replacement) == item['new_sha256'],
                    'Patched content SHA256 differs: ' + rel)
            require(current != replacement, 'No intended change: ' + rel)
            require((b'\r\n' in current) == (b'\r\n' in replacement),
                    'Line endings differ: ' + rel)
            require((b'\n' not in current.replace(b'\r\n', b'')) and
                    (b'\n' not in replacement.replace(b'\r\n', b''))
                    if b'\r\n' in current else b'\r\n' not in replacement,
                    'Mixed line endings: ' + rel)
            originals[rel] = current
            patches[rel] = replacement
            require(source_before[rel] == item['old_sha256'],
                    'Inventory baseline differs: ' + rel)

    print('PASS: patch ZIP SHA256 and 17 source baselines', flush=True)
    phase = 'verified backups'
    require(snapshot() == source_before, 'Source changed during preflight')
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8]
    backup_dir = backup_base / ('215_' + stamp)
    require(not backup_dir.exists(), 'Backup directory already exists')
    backup_dir.mkdir(parents=True)
    for rel in originals:
        backup = backup_dir / rel
        shutil.copy2(src / rel, backup)
        require(hash_file(backup) == hash_bytes(originals[rel]),
                'Backup SHA256 invalid: ' + rel)
        backups[rel] = backup
    print('PASS: 17 verified SHA256 backups', flush=True)

    phase = 'exact source patch'
    require(snapshot() == source_before, 'Source changed before modifications')
    started = True
    for rel, new_bytes in patches.items():
        require((src / rel).read_bytes() == originals[rel],
                'Source changed during patch: ' + rel)
        (src / rel).write_bytes(new_bytes)
        require((src / rel).read_bytes() == new_bytes,
                'Patched source differs: ' + rel)
    print('PASS: 671 approved UI text occurrences applied', flush=True)

    phase = 'production build and full ESLint'
    build_and_lint(node, npm)

    phase = 'final integrity verification'
    after = snapshot()
    require(set(after) == set(source_before), 'Source file inventory changed')
    for rel, before_hash in source_before.items():
        expected = hash_bytes(patches[rel]) if rel in patches else before_hash
        require(after[rel] == expected, 'Unexpected change: ' + rel)
    for rel, backup in backups.items():
        require(hash_file(backup) == hash_bytes(originals[rel]),
                'Backup SHA256 changed: ' + rel)
    require(hash_file(package) == EXPECTED_PACKAGE,
            'Patch ZIP SHA256 changed')

    print('=== STEP 215 PASSED ===', flush=True)
    print('SOURCES CHANGED:', len(patches), flush=True)
    print('UI TEXT OCCURRENCES:', 671, flush=True)
    print('TRANSLATION KEYS:', 362, flush=True)
    print('PASS: build, full ESLint 0/0, exact diff, SHA256 backups', flush=True)
    print('BACKUP DIRECTORY:', backup_dir, flush=True)
    print('NO BACKEND, DATABASE, API, ETL OR DQ CHANGES', flush=True)

except Exception as exc:
    print('STOP: PHASE =', phase, flush=True)
    print('ERROR TYPE:', type(exc).__name__, flush=True)
    print('ERROR:', str(exc), flush=True)
    if started:
        print('=== AUTOMATIC SOURCE ROLLBACK ===', flush=True)
        try:
            require(len(backups) == len(originals),
                    'Missing backups for rollback')
            for rel, backup in backups.items():
                require(backup.is_file() and
                        hash_file(backup) == hash_bytes(originals[rel]),
                        'Invalid rollback backup: ' + rel)
                current = (src / rel).read_bytes()
                require(current in (originals[rel], patches[rel]),
                        'Concurrent changes prevent safe rollback: ' + rel)
            for rel, backup in backups.items():
                if (src / rel).read_bytes() != originals[rel]:
                    shutil.copy2(backup, src / rel)
                require(hash_file(src / rel) == hash_bytes(originals[rel]),
                        'Rollback SHA256 mismatch: ' + rel)
            require(snapshot() == source_before,
                    'Full source snapshot rollback mismatch')
            print('PASS: all sources restored; SHA256 verified', flush=True)
        except Exception as rollback_exc:
            print('WARNING: ROLLBACK NOT FULLY VERIFIED:',
                  type(rollback_exc).__name__, str(rollback_exc), flush=True)
    print('STEP 215 NOT VERIFIED', flush=True)
    sys.exit(1)
